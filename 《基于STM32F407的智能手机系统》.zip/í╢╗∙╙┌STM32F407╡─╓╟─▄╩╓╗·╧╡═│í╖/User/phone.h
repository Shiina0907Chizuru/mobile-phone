#ifndef PHONE_H
#define PHONE_H


//  变量声明
extern const unsigned char gImage_phone[];


#endif