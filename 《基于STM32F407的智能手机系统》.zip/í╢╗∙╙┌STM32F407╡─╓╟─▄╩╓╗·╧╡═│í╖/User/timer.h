#ifndef TIMER_H
#define TIMER_H


//  变量声明
extern const unsigned char gImage_timer[];


#endif