#ifndef P1_H
#define P1_H


//  变量声明
extern const unsigned char gImage_p1[];


#endif