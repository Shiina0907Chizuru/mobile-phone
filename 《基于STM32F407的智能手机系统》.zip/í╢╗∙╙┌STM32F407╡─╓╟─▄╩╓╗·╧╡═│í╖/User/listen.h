#ifndef LISTEN_H
#define LISTEN_H


//  变量声明
extern const unsigned char gImage_listen[];


#endif