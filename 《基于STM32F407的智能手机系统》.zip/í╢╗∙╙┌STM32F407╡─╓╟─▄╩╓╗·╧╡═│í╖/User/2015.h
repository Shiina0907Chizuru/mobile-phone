#ifndef PICTURE2015_H
#define PICTURE2015_H

//  变量声明
extern const unsigned char gImage_2015[];

#endif