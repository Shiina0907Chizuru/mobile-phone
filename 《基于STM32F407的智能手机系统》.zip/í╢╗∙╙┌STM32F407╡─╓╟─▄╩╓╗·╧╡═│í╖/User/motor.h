#ifndef MOTOR_H
#define MOTOR_H


//  变量声明
extern const unsigned char gImage_motor[];


#endif