#ifndef LIGHT_H
#define LIGHT_H


//  变量声明
extern const unsigned char gImage_light[];


#endif