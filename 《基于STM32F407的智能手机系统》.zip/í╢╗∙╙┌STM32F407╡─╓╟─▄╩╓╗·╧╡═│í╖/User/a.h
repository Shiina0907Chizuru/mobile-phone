#ifndef A_H
#define A_H


//  变量声明
extern const unsigned char gImage_a[];


#endif