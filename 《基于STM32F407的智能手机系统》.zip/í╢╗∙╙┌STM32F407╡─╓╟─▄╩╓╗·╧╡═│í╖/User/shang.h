#ifndef SHANG_H
#define SAHNG_H


//  变量声明
extern const unsigned char gImage_shang[];


#endif