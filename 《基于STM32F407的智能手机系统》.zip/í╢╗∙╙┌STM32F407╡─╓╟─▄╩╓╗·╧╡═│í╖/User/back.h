#ifndef BACK_H
#define BACK_H


//  变量声明
extern const unsigned char gImage_back[];


#endif