#ifndef GPS1_H
#define GPS1_H


//  变量声明
extern const unsigned char gImage_gps1[];


#endif