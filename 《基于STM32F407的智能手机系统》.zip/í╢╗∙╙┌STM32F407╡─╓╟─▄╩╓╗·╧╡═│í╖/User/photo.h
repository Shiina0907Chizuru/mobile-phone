#ifndef PHOTO_H
#define PHOTO_H


//  变量声明
extern const unsigned char gImage_photo[];


#endif
