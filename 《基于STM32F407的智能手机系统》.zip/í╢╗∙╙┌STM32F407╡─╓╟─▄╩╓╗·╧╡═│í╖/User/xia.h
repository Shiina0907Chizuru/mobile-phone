#ifndef XIA_H
#define XIA_H


//  变量声明
extern const unsigned char gImage_xia[];


#endif