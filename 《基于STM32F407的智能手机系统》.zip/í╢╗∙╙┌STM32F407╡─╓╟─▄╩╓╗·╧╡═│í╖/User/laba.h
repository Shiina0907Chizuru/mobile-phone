#ifndef LABA_H
#define LABA_H


//  变量声明
extern const unsigned char gImage_laba[];


#endif