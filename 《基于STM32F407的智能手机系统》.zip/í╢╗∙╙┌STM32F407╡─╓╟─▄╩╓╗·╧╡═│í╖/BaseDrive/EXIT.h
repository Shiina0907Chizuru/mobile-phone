#ifndef _EXIT_H_
#define _EXIT_H_

void EXTI_Config(void);

#endif
